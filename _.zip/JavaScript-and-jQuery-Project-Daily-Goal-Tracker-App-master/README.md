## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/javascript-and-jquery-project-daily-goal-tracker-app-video/9781800206892)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# JavaScript-and-jQuery-Project-Daily-Goal-Tracker-App
JavaScript and jQuery Project:  Daily Goal Tracker App by Packt Publishing
